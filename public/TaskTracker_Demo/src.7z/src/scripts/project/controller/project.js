(function () {
    'use strict';
    angular.module('app')
    .controller('projectCtrl', function($scope) {
        $scope.name = '';
        $scope.description = '';
        $scope.newproject = {};
        $scope.clickedProject = {};
        $scope.projects = [
            {id: 1, name: 'Trần Phương Thảo', description: "Thốt Nốt_Cần Thơ"},
            {id: 2, name: 'Vàng Nguyễn', description: "Châu Phú_An Giang"},
            {id: 3, name: 'Name 1', description: "Desc 1"},
            {id: 4, name: 'Name 2', description: "Desc 2"},
            {id: 5, name: 'Name 3', description: "Desc 3"}
        ];
        // $scope.saveProject = function(){
        //     //tao 1 project moi
        //     var newp = {};
        //     newp.name = $scope.newproject.name;
        //     newp.description = $scope.newproject.description;
        //     $scope.projects.push(newp);
        //     // $scope.projects.push($scope.newProject);(do them vao van con giu gia tri truoc)
        //     $scope.newproject = {};
        //     //$scope.newProject = {};
        // };

        $scope.prepareCreateForm = function () {
            $scope.myForm.$setPristine();
        };

        // $scope.saveProject =function ($event) {
        //     if($scope.myForm.$invalid) {
        //         $event.preventDefault();
        //         $event.stopPropagation();
        //         $scope.isFormChecked = true;
        //     }
        //
        //   // $('#create-project-form')[0].classList.add('was-validated');
        //
        //   // var newp =angular.copy($scope.newproject);
        //   // $scope.projects.push($scope.newproject);
        //   // $scope.newproject={};
        //
        // };

        $scope.saveProject = function () {
            var newp = angular.copy($scope.newproject);
            $scope.projects.push($scope.newproject);
            $scope.newproject = {};

            // $('#myModal').hide();
            // $('.modal-backdrop').hide();
        };

        $scope.selectProject = function (projects, index) {
            console.log(projects);
            // $scope.clickedProject = projects;
            $scope.clickedProject = angular.copy(projects);
            $scope.clickedProjectIndex = index;

        };
        $scope.editProject = function () {

            $scope.projects[$scope.clickedProjectIndex] = angular.copy($scope.clickedProject);
        };
        $scope.deleteProject = function () {

            $scope.projects.splice($scope.projects.indexOf($scope.clickedProject), 1);

        };

        $scope.selectedList = [];
        $scope.exist = function (item) {
            return $scope.selectedList.indexOf(item) > -1;
        }
        $scope.toggleSelection = function (item) {
            var x = $scope.selectedList.indexOf(item);
            if (x > -1) {
                //$scope.selectedList.splice(item,1);
                $scope.selectedList.splice(x, 1);
            }
            else {
                $scope.selectedList.push(item);
            }
        }
        $scope.checkAll = function () {
            if ($scope.selectAll) {
                angular.forEach($scope.projects, function (item) {
                    x = $scope.selectedList.indexOf(item);
                    if (x >= 0) {
                        return true;
                    }
                    else {
                        $scope.selectedList.push(item);
                    }
                })
            }
            else {
                $scope.selectedList = [];
            }
        }
        $scope.myBtn = $scope.selectedList.length;
    })

}());