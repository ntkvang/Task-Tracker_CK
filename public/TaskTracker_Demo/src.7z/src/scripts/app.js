(function () {
    'use strict';
angular.module('app', ['ngRoute'])
    .config(['$routeProvider', '$locationProvider', function ($routeProvider, $locationProvider) {
        $locationProvider.hashPrefix('');

        $routeProvider
            .when("/",{
                templateUrl:'scripts/timeline/templates/timeline.html',
                controller:'MainCtrl'
            })
            .when("/task",{
                templateUrl:'scripts/task/templates/task.html',
                controller:'TaskCtrl'

            })
            .when("/timeline",{
                templateUrl:'scripts/timeline/templates/timeline.html'
                // controller:'MaintCtrl'
            })
            .when("/project",{
                templateUrl:'scripts/project/templates/project.html',
                 controller:'projectCtrl'
            })
            .otherwise({
                redirectTo: '/timeline'
            });
    }])
    .controller('MainCtrl', ['$scope', 'SampleService', function($scope, abc) {
        var service = abc;
        $scope.varFromService = service.key;
    $scope.title = 'This is Time line page';
}])
    .directive('ngTagsInput', function(){
        return {
            template: '<div>ng-tag-input directive</div>'
        }
    })
    .factory('SampleService', [function(){
        return {
            key: 123
        };
    }])}());
